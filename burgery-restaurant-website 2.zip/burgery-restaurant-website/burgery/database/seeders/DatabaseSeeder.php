<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            AdminUserSeeder::class,
            SettingSeeder::class,
            PageSeeder::class,
            MenuSeeder::class,
            ArticleSeeder::class,
            GallerySeeder::class,
            TestimonialSeeder::class,
        ]);
    }
}
