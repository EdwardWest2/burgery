<?php $__env->startSection('title', 'Lokasi'); ?>
<?php $__env->startSection('heading', 'Lokasi'); ?>
<?php $__env->startSection('actions'); ?><a href="<?php echo e(route('admin.locations.create')); ?>" class="btn btn-brand btn-sm"><i class="fas fa-plus me-1"></i>Tambah lokasi</a><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card-a">
    <p class="hint mb-3">Lokasi tambahan tampil di halaman Kontak. Alamat utama diatur di <a href="<?php echo e(route('admin.settings.edit')); ?>">Pengaturan</a>.</p>
    <?php if($locations->isEmpty()): ?>
        <div class="empty-a"><i class="fas fa-location-dot"></i>Belum ada lokasi tambahan.</div>
    <?php else: ?>
        <div class="tbl-wrap"><table class="tbl">
            <thead><tr><th>Nama</th><th>Alamat</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="title"><?php echo e($l->name); ?></td>
                    <td class="sub"><?php echo e(\Illuminate\Support\Str::limit($l->address, 70)); ?></td>
                    <td><span class="pill <?php echo e($l->is_active ? 'published' : 'off'); ?>"><?php echo e($l->is_active ? 'Aktif' : 'Nonaktif'); ?></span></td>
                    <td class="acts"><a class="btn-line btn-sm-x" href="<?php echo e(route('admin.locations.edit', $l)); ?>">Edit</a>
                        <?php echo $__env->make('admin.partials.delete-form', ['action' => route('admin.locations.destroy', $l), 'confirm' => 'Hapus lokasi "'.$l->name.'"?'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/admin/locations/index.blade.php ENDPATH**/ ?>