<?php $__env->startSection('title', 'Menu'); ?>
<?php $__env->startSection('heading', 'Menu'); ?>
<?php $__env->startSection('actions'); ?><a href="<?php echo e(route('admin.menu-items.create')); ?>" class="btn btn-brand btn-sm"><i class="fas fa-plus me-1"></i>Tambah menu</a><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card-a">
    <form method="GET" class="row g-2 mb-3">
        <div class="col-md-6"><input type="search" name="q" value="<?php echo e($filters['search']); ?>" class="form-control" placeholder="Cari nama menu..."></div>
        <div class="col-md-4">
            <select name="category" class="form-select" aria-label="Kategori">
                <option value="">Semua kategori</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php if($filters['category'] === $c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-2 d-flex gap-2"><button class="btn btn-line flex-fill" type="submit">Cari</button><?php if($filters['search'] || $filters['category']): ?><a class="btn btn-line" href="<?php echo e(route('admin.menu-items.index')); ?>">Reset</a><?php endif; ?></div>
    </form>
    <?php if($items->isEmpty()): ?>
        <div class="empty-a"><i class="fas fa-burger"></i>Belum ada menu yang cocok.
            <div class="mt-3"><a class="btn btn-brand btn-sm" href="<?php echo e(route('admin.menu-items.create')); ?>">Tambah menu</a></div></div>
    <?php else: ?>
        <div class="tbl-wrap"><table class="tbl">
            <thead><tr><th></th><th>Nama</th><th>Kategori</th><th>Harga</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><img class="thumb" src="<?php echo e($m->image_url); ?>" alt=""></td>
                    <td><div class="title"><?php echo e($m->name); ?> <?php if($m->is_featured): ?><i class="fas fa-star" style="color:var(--secondary);" title="Unggulan"></i><?php endif; ?></div><div class="sub">Urutan <?php echo e($m->sort_order); ?></div></td>
                    <td><?php echo e($m->category->name); ?></td>
                    <td><?php echo e($m->price_label); ?></td>
                    <td><span class="pill <?php echo e($m->is_available ? 'published' : 'off'); ?>"><?php echo e($m->is_available ? 'Tersedia' : 'Habis'); ?></span></td>
                    <td class="acts">
                        <a class="btn-line btn-sm-x" href="<?php echo e(route('admin.menu-items.edit', $m)); ?>">Edit</a>
                        <a class="btn-line btn-sm-x" href="<?php echo e(route('menu.show', $m->slug)); ?>" target="_blank" rel="noopener">Lihat</a>
                        <?php echo $__env->make('admin.partials.delete-form', ['action' => route('admin.menu-items.destroy', $m), 'confirm' => 'Hapus menu "'.$m->name.'"?'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table></div>
        <div class="mt-3"><?php echo e($items->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/admin/menu-items/index.blade.php ENDPATH**/ ?>