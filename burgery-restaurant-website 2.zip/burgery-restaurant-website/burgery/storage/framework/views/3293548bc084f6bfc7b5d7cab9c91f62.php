<?php $hours = parse_hours(setting('opening_hours')); ?>
<footer>
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-4">
                <div class="fnm"><?php echo e(brand_wordmark()); ?></div>
                <p class="fdesc"><?php echo e(setting('brand_description')); ?></p>
                <div class="fsoc">
                    <?php $__currentLoopData = social_links(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($s['url']); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo e($s['label']); ?>"><i class="<?php echo e($s['icon']); ?>"></i></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-sm-6 col-lg-2">
                <div class="ftit">Tautan</div>
                <ul class="flinks ps-0">
                    <li><a href="<?php echo e(route('home')); ?>"><i class="fas fa-chevron-right"></i>Beranda</a></li>
                    <li><a href="<?php echo e(route('about')); ?>"><i class="fas fa-chevron-right"></i>Tentang Kami</a></li>
                    <li><a href="<?php echo e(route('menu.index')); ?>"><i class="fas fa-chevron-right"></i>Menu</a></li>
                    <li><a href="<?php echo e(route('articles.index')); ?>"><i class="fas fa-chevron-right"></i>Artikel</a></li>
                    <li><a href="<?php echo e(route('gallery')); ?>"><i class="fas fa-chevron-right"></i>Galeri</a></li>
                    <li><a href="<?php echo e(route('contact')); ?>"><i class="fas fa-chevron-right"></i>Kontak</a></li>
                </ul>
            </div>
            <div class="col-sm-6 col-lg-2">
                <div class="ftit">Menu Kami</div>
                <ul class="flinks ps-0">
                    <?php $__currentLoopData = $navCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('menu.index', ['kategori' => $c->slug])); ?>"><i class="fas fa-chevron-right"></i><?php echo e($c->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="col-lg-4">
                <div class="ftit">Hubungi Kami</div>
                <?php if(setting('address')): ?>
                <div class="fci">
                    <div class="fciico"><i class="fas fa-map-marker-alt"></i></div>
                    <div class="fciinfo"><strong>Alamat</strong><?php echo e(setting('address')); ?></div>
                </div>
                <?php endif; ?>
                <?php if(setting('phone')): ?>
                <div class="fci">
                    <div class="fciico"><i class="fas fa-phone-alt"></i></div>
                    <div class="fciinfo"><strong>Telepon</strong><?php echo e(setting('phone')); ?></div>
                </div>
                <?php endif; ?>
                <?php if(setting('email')): ?>
                <div class="fci">
                    <div class="fciico"><i class="fas fa-envelope"></i></div>
                    <div class="fciinfo"><strong>Email</strong><?php echo e(setting('email')); ?></div>
                </div>
                <?php endif; ?>
                <?php if($hours): ?>
                <div class="fci">
                    <div class="fciico"><i class="fas fa-clock"></i></div>
                    <div class="fciinfo"><strong>Jam operasional</strong>
                        <?php $__currentLoopData = $hours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($h['label']); ?><?php if($h['time']): ?>: <?php echo e($h['time']); ?><?php endif; ?><br/><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="fbot">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                <p>&copy; <?php echo e(date('Y')); ?> <span><?php echo e(setting('brand_name')); ?></span>. <?php echo e(setting('footer_text')); ?></p>
                <div><a href="<?php echo e(route('privacy')); ?>">Kebijakan Privasi</a><a href="<?php echo e(route('contact')); ?>">Kontak</a></div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/partials/footer.blade.php ENDPATH**/ ?>