<?php $__env->startSection('title', 'Galeri'); ?>
<?php $__env->startSection('description', 'Galeri foto '.setting('brand_name').'.'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.page-header', ['heading' => 'Galeri', 'crumbs' => ['Galeri' => null], 'lead' => 'Foto-foto dari dapur dan ruang makan kami.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<section id="gallery" class="pgbody">
    <div class="container">
        <?php if($photos->isEmpty()): ?>
            <div class="emptybox"><i class="fas fa-images"></i><p>Belum ada foto di galeri.</p></div>
        <?php else: ?>
            <div class="ggrid ggrid-flow">
                <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button type="button" class="gitem" data-gi="<?php echo e($i); ?>"
                        data-gimg="<?php echo e($photo->image_url); ?>"
                        data-gtitle="<?php echo e($photo->caption); ?>"
                        data-gdesc="<?php echo e($photo->alt_text); ?>">
                        <img src="<?php echo e($photo->image_url); ?>" alt="<?php echo e($photo->alt_text ?: $photo->caption); ?>" loading="lazy"/>
                        <div class="gover"><span><i class="fas fa-expand-alt"></i> <?php echo e($photo->caption ?: 'Perbesar'); ?></span></div>
                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo $__env->make('partials.gallery-popup', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/site/gallery.blade.php ENDPATH**/ ?>