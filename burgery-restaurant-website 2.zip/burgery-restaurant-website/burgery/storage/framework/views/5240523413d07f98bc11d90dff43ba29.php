<?php $__env->startSection('title', 'Kategori Artikel'); ?>
<?php $__env->startSection('heading', 'Kategori Artikel'); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-4">
    <div class="col-lg-4">
        <div class="card-a">
            <h2>Tambah kategori</h2>
            <form method="POST" action="<?php echo e(route('admin.article-categories.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3"><label class="form-label" for="name">Nama *</label><input id="name" name="name" class="form-control" value="<?php echo e(old('name')); ?>" maxlength="100" required></div>
                <div class="mb-3"><label class="form-label" for="description">Deskripsi</label><textarea id="description" name="description" rows="3" class="form-control" maxlength="500"><?php echo e(old('description')); ?></textarea></div>
                <button class="btn btn-brand" type="submit">Tambah kategori</button>
            </form>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="card-a">
            <?php if($categories->isEmpty()): ?>
                <div class="empty-a"><i class="fas fa-tags"></i>Belum ada kategori. Tambahkan kategori pertama di samping.</div>
            <?php else: ?>
            <div class="tbl-wrap"><table class="tbl">
                <thead><tr><th>Nama</th><th>Slug</th><th>Jumlah artikel</th><th></th></tr></thead>
                <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="title"><?php echo e($c->name); ?></td>
                        <td class="sub"><?php echo e($c->slug); ?></td>
                        <td><a href="<?php echo e(route('admin.articles.index', ['category' => $c->id])); ?>"><?php echo e($c->articles_count); ?> artikel</a></td>
                        <td class="acts">
                            <a class="btn-line btn-sm-x" href="<?php echo e(route('admin.article-categories.edit', $c)); ?>">Edit</a>
                            <?php echo $__env->make('admin.partials.delete-form', ['action' => route('admin.article-categories.destroy', $c), 'confirm' => 'Hapus kategori "'.$c->name.'"?'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table></div>
            <div class="hint mt-2">Kategori yang masih memiliki artikel tidak dapat dihapus.</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/admin/article-categories/index.blade.php ENDPATH**/ ?>