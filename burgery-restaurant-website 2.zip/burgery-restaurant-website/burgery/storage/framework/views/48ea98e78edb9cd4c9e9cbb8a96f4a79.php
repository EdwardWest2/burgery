<?php $isEdit = $article->exists; ?>
<?php $__env->startSection('title', $isEdit ? 'Edit Artikel' : 'Artikel Baru'); ?>
<?php $__env->startSection('heading', $isEdit ? 'Edit Artikel' : 'Artikel Baru'); ?>
<?php $__env->startSection('actions'); ?>
    <?php if($isEdit): ?><a href="<?php echo e(route('admin.articles.preview', $article)); ?>" target="_blank" rel="noopener" class="btn btn-line btn-sm"><i class="fas fa-eye me-1"></i>Pratinjau</a>
        <?php if($article->isLive()): ?><a href="<?php echo e(route('articles.show', $article->slug)); ?>" target="_blank" rel="noopener" class="btn btn-line btn-sm"><i class="fas fa-arrow-up-right-from-square me-1"></i>Lihat di website</a><?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form method="POST" enctype="multipart/form-data" action="<?php echo e($isEdit ? route('admin.articles.update', $article) : route('admin.articles.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($isEdit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <div class="row g-4">
        <div class="col-xl-8">
            <div class="card-a">
                <div class="mb-3">
                    <label class="form-label" for="title">Judul *</label>
                    <input id="title" name="title" type="text" class="form-control form-control-lg" value="<?php echo e(old('title', $article->title)); ?>" maxlength="200" required data-slug-source>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="slug">Slug (alamat artikel)</label>
                    <div class="input-group"><span class="input-group-text">/artikel/</span>
                        <input id="slug" name="slug" type="text" class="form-control" value="<?php echo e(old('slug', $article->slug)); ?>" maxlength="200" placeholder="dibuat otomatis dari judul" data-slug-target></div>
                    <div class="hint">Huruf kecil, angka, dan tanda hubung. Jika kosong atau sudah dipakai, sistem membuat slug unik otomatis.</div>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="excerpt">Ringkasan</label>
                    <textarea id="excerpt" name="excerpt" rows="3" class="form-control" maxlength="500"><?php echo e(old('excerpt', $article->excerpt)); ?></textarea>
                    <div class="hint">Tampil di daftar artikel dan sebagai pembuka artikel. Jika kosong, diambil dari isi artikel.</div>
                </div>
                <div>
                    <label class="form-label" for="body">Isi artikel *</label>
                    <?php echo $__env->make('admin.partials.editor', ['name' => 'body', 'id' => 'body', 'value' => old('body', $article->body)], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>

            <div class="card-a">
                <h2>SEO</h2>
                <div class="mb-3">
                    <label class="form-label" for="seo_title">SEO title</label>
                    <input id="seo_title" name="seo_title" type="text" class="form-control" value="<?php echo e(old('seo_title', $article->seo_title)); ?>" maxlength="200" placeholder="Jika kosong, memakai judul artikel">
                </div>
                <div>
                    <label class="form-label" for="meta_description">Meta description</label>
                    <textarea id="meta_description" name="meta_description" rows="2" class="form-control" maxlength="320" data-counter="mdCount"><?php echo e(old('meta_description', $article->meta_description)); ?></textarea>
                    <div class="hint"><span id="mdCount"></span> &middot; ideal 120-160 karakter. Jika kosong, memakai ringkasan.</div>
                </div>
            </div>
        </div>

        <div class="col-xl-4">
            <div class="card-a">
                <h2>Penerbitan</h2>
                <div class="mb-3">
                    <label class="form-label" for="status">Status</label>
                    <select id="status" name="status" class="form-select">
                        <option value="draft" <?php if(old('status', $article->status) === 'draft'): echo 'selected'; endif; ?>>Draft (tidak tampil di website)</option>
                        <option value="published" <?php if(old('status', $article->status) === 'published'): echo 'selected'; endif; ?>>Published (tayang)</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="published_at">Tanggal terbit</label>
                    <input id="published_at" name="published_at" type="datetime-local" class="form-control" value="<?php echo e(old('published_at', $article->published_at?->format('Y-m-d\TH:i'))); ?>">
                    <div class="hint">Kosong + Published = terbit sekarang. Tanggal di masa depan + Published = <strong>terjadwal</strong>: artikel otomatis tayang saat waktunya tiba (tanpa cron).</div>
                </div>
                <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" name="is_featured" id="is_featured" value="1" <?php if(old('is_featured', $article->is_featured)): echo 'checked'; endif; ?>>
                    <label class="form-check-label" for="is_featured">Artikel unggulan (diutamakan di beranda)</label>
                </div>
                <div class="d-grid gap-2">
                    <button class="btn btn-brand" type="submit"><i class="fas fa-floppy-disk me-1"></i>Simpan</button>
                    <a href="<?php echo e(route('admin.articles.index')); ?>" class="btn btn-line">Kembali ke daftar</a>
                </div>
            </div>

            <div class="card-a">
                <h2>Kategori &amp; penulis</h2>
                <div class="mb-3">
                    <label class="form-label" for="article_category_id">Kategori *</label>
                    <select id="article_category_id" name="article_category_id" class="form-select" required>
                        <option value="">Pilih kategori</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php if((int) old('article_category_id', $article->article_category_id) === $c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($categories->isEmpty()): ?><div class="hint text-danger">Belum ada kategori. <a href="<?php echo e(route('admin.article-categories.index')); ?>">Buat kategori dulu</a>.</div><?php endif; ?>
                </div>
                <div>
                    <label class="form-label" for="author_id">Penulis</label>
                    <select id="author_id" name="author_id" class="form-select">
                        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($u->id); ?>" <?php if((int) old('author_id', $article->author_id ?: auth()->id()) === $u->id): echo 'selected'; endif; ?>><?php echo e($u->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="card-a">
                <h2>Gambar utama</h2>
                <img id="imgPrev" class="img-prev" src="<?php echo e($article->featured_image ? $article->image_url : ''); ?>" alt="" style="<?php echo e($article->featured_image ? '' : 'display:none'); ?>">
                <input class="form-control mb-2" type="file" name="featured_image" accept="image/jpeg,image/png,image/webp" data-preview="imgPrev">
                <div class="hint mb-3">JPG, PNG, atau WebP, maks. 3 MB. Disarankan rasio 16:9.</div>
                <label class="form-label" for="featured_image_alt">Alt text gambar</label>
                <input id="featured_image_alt" name="featured_image_alt" type="text" class="form-control" value="<?php echo e(old('featured_image_alt', $article->featured_image_alt)); ?>" maxlength="200" placeholder="Deskripsi singkat gambar">
                <?php if($isEdit && $article->featured_image): ?>
                    <div class="form-check mt-3"><input class="form-check-input" type="checkbox" name="remove_image" id="remove_image" value="1"><label class="form-check-label" for="remove_image">Hapus gambar utama</label></div>
                <?php endif; ?>
            </div>

            <?php if($isEdit): ?>
            <div class="card-a">
                <h2>Zona berbahaya</h2>
                <?php echo $__env->make('admin.partials.delete-form', ['action' => route('admin.articles.destroy', $article), 'confirm' => 'Hapus artikel ini beserta gambar utamanya? Tindakan ini tidak dapat dibatalkan.', 'label' => 'Hapus artikel'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/admin/articles/form.blade.php ENDPATH**/ ?>