<?php $__env->startSection('title', 'Kategori Menu'); ?>
<?php $__env->startSection('heading', 'Kategori Menu'); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-4">
    <div class="col-lg-4">
        <div class="card-a">
            <h2>Tambah kategori</h2>
            <form method="POST" action="<?php echo e(route('admin.menu-categories.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3"><label class="form-label" for="name">Nama *</label><input id="name" name="name" class="form-control" value="<?php echo e(old('name')); ?>" maxlength="100" required></div>
                <div class="mb-3"><label class="form-label" for="sort_order">Urutan</label><input id="sort_order" name="sort_order" type="number" min="0" class="form-control" value="<?php echo e(old('sort_order', 0)); ?>"><div class="hint">Angka kecil tampil lebih dulu.</div></div>
                <button class="btn btn-brand" type="submit">Tambah kategori</button>
            </form>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="card-a">
            <?php if($categories->isEmpty()): ?>
                <div class="empty-a"><i class="fas fa-list"></i>Belum ada kategori menu.</div>
            <?php else: ?>
            <div class="tbl-wrap"><table class="tbl">
                <thead><tr><th>Urutan</th><th>Nama</th><th>Jumlah menu</th><th></th></tr></thead>
                <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($c->sort_order); ?></td>
                        <td class="title"><?php echo e($c->name); ?><div class="sub"><?php echo e($c->slug); ?></div></td>
                        <td><a href="<?php echo e(route('admin.menu-items.index', ['category' => $c->id])); ?>"><?php echo e($c->items_count); ?> menu</a></td>
                        <td class="acts">
                            <a class="btn-line btn-sm-x" href="<?php echo e(route('admin.menu-categories.edit', $c)); ?>">Edit</a>
                            <?php echo $__env->make('admin.partials.delete-form', ['action' => route('admin.menu-categories.destroy', $c), 'confirm' => 'Hapus kategori "'.$c->name.'"?'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table></div>
            <div class="hint mt-2">Kategori yang masih berisi menu tidak dapat dihapus.</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/admin/menu-categories/index.blade.php ENDPATH**/ ?>