<?php $__env->startSection('title', 'Artikel'); ?>
<?php $__env->startSection('description', 'Artikel, tips, dan kabar terbaru dari '.setting('brand_name').'.'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.page-header', ['heading' => 'Artikel', 'crumbs' => ['Artikel' => null], 'lead' => 'Cerita, tips, dan kabar terbaru.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<section id="blog" class="pgbody">
    <div class="container">
        <form method="GET" action="<?php echo e(route('articles.index')); ?>" class="listsearch" role="search">
            <?php if($activeCategory !== ''): ?><input type="hidden" name="kategori" value="<?php echo e($activeCategory); ?>"><?php endif; ?>
            <input type="search" name="q" value="<?php echo e($search); ?>" placeholder="Cari judul atau ringkasan artikel..." maxlength="100" aria-label="Cari artikel">
            <button type="submit" aria-label="Cari"><i class="fas fa-search"></i></button>
        </form>

        <?php if($categories->isNotEmpty()): ?>
        <div class="text-center mb-4">
            <a class="filtbtn <?php echo e($activeCategory === '' ? 'active' : ''); ?>" href="<?php echo e(route('articles.index', array_filter(['q' => $search]))); ?>">Semua</a>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="filtbtn <?php echo e($activeCategory === $c->slug ? 'active' : ''); ?>" href="<?php echo e(route('articles.index', array_filter(['kategori' => $c->slug, 'q' => $search]))); ?>"><?php echo e($c->name); ?> <small>(<?php echo e($c->articles_count); ?>)</small></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <?php if($articles->isEmpty()): ?>
            <div class="emptybox">
                <i class="fas fa-newspaper"></i>
                <p><?php echo e(($search !== '' || $activeCategory !== '') ? 'Tidak ada artikel yang cocok dengan pencarian Anda.' : 'Belum ada artikel yang diterbitkan.'); ?></p>
                <?php if($search !== '' || $activeCategory !== ''): ?><a href="<?php echo e(route('articles.index')); ?>" class="btn-red">Tampilkan semua artikel</a><?php endif; ?>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials.article-card', ['article' => $article, 'delay' => $i % 3], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="mt-5 d-flex justify-content-center"><?php echo e($articles->links()); ?></div>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/site/articles/index.blade.php ENDPATH**/ ?>