<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('heading', 'Dashboard'); ?>
<?php $__env->startSection('actions'); ?><a href="<?php echo e(route('admin.articles.create')); ?>" class="btn btn-brand btn-sm"><i class="fas fa-plus me-1"></i>Artikel baru</a><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-3 mb-4">
    <?php $__currentLoopData = [
        ['Total artikel', $stats['articles'], 'fa-newspaper', route('admin.articles.index')],
        ['Artikel published', $stats['published'], 'fa-circle-check', route('admin.articles.index', ['status' => 'published'])],
        ['Artikel draft', $stats['drafts'], 'fa-pen-to-square', route('admin.articles.index', ['status' => 'draft'])],
        ['Kategori artikel', $stats['categories'], 'fa-tags', route('admin.article-categories.index')],
        ['Item menu', $stats['menus'], 'fa-burger', route('admin.menu-items.index')],
        ['Pesan kontak', $stats['messages'], 'fa-envelope', route('admin.messages.index')],
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $n, $icon, $url]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-lg-4 col-xl-2">
            <a class="stat" href="<?php echo e($url); ?>"><i class="fas <?php echo e($icon); ?>"></i><div class="n"><?php echo e($n); ?></div><div class="l"><?php echo e($label); ?></div></a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php if($stats['new_messages'] > 0): ?>
    <div class="flash ok"><i class="fas fa-envelope me-1"></i>Ada <strong><?php echo e($stats['new_messages']); ?></strong> pesan baru. <a href="<?php echo e(route('admin.messages.index', ['status' => 'new'])); ?>">Buka pesan</a></div>
<?php endif; ?>

<div class="card-a">
    <h2>Artikel terbaru diperbarui</h2>
    <?php if($latest->isEmpty()): ?>
        <div class="empty-a"><i class="fas fa-newspaper"></i>Belum ada artikel. <a href="<?php echo e(route('admin.articles.create')); ?>">Tulis artikel pertama</a>.</div>
    <?php else: ?>
        <div class="tbl-wrap"><table class="tbl">
            <thead><tr><th>Judul</th><th>Kategori</th><th>Status</th><th>Diperbarui</th><th></th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="title"><?php echo e($a->title); ?></td>
                    <td><?php echo e($a->category->name); ?></td>
                    <td><?php echo $__env->make('admin.partials.article-status', ['article' => $a], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                    <td class="sub"><?php echo e($a->updated_at->translatedFormat('j M Y H:i')); ?></td>
                    <td class="acts"><a class="btn-line btn-sm-x" href="<?php echo e(route('admin.articles.edit', $a)); ?>">Edit</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>