<?php $__env->startSection('title', 'Pesan Kontak'); ?>
<?php $__env->startSection('heading', 'Pesan Kontak'); ?>

<?php $__env->startSection('content'); ?>
<div class="card-a">
    <form method="GET" class="row g-2 mb-3">
        <div class="col-md-6"><input type="search" name="q" value="<?php echo e($filters['search']); ?>" class="form-control" placeholder="Cari nama, email, subjek, atau isi pesan..."></div>
        <div class="col-md-4">
            <select name="status" class="form-select" aria-label="Status">
                <option value="">Semua status</option>
                <?php $__currentLoopData = \App\Models\ContactMessage::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($k); ?>" <?php if($filters['status'] === $k): echo 'selected'; endif; ?>><?php echo e($label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-2 d-flex gap-2"><button class="btn btn-line flex-fill" type="submit">Cari</button><?php if($filters['search'] || $filters['status']): ?><a class="btn btn-line" href="<?php echo e(route('admin.messages.index')); ?>">Reset</a><?php endif; ?></div>
    </form>
    <?php if($messages->isEmpty()): ?>
        <div class="empty-a"><i class="fas fa-envelope-open"></i>Tidak ada pesan.</div>
    <?php else: ?>
        <div class="tbl-wrap"><table class="tbl">
            <thead><tr><th>Pengirim</th><th>Subjek</th><th>Status</th><th>Diterima</th><th></th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><div class="title" <?php if($m->status === 'new'): ?> style="color:var(--primary)" <?php endif; ?>><?php echo e($m->name); ?></div><div class="sub"><?php echo e($m->email); ?></div></td>
                    <td><?php echo e($m->subject); ?><div class="sub"><?php echo e(\Illuminate\Support\Str::limit($m->message, 70)); ?></div></td>
                    <td><span class="pill <?php echo e($m->status); ?>"><?php echo e($m->status_label); ?></span></td>
                    <td class="sub"><?php echo e($m->created_at->translatedFormat('j M Y H:i')); ?></td>
                    <td class="acts"><a class="btn-line btn-sm-x" href="<?php echo e(route('admin.messages.show', $m)); ?>">Buka</a>
                        <?php echo $__env->make('admin.partials.delete-form', ['action' => route('admin.messages.destroy', $m), 'confirm' => 'Hapus pesan dari '.$m->name.'?'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table></div>
        <div class="mt-3"><?php echo e($messages->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/admin/messages/index.blade.php ENDPATH**/ ?>