<div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="<?php echo e(($delay ?? 0) * 80); ?>">
    <div class="blcard">
        <div class="blimg">
            <a href="<?php echo e(route('articles.show', $article->slug)); ?>" tabindex="-1" aria-hidden="true">
                <img src="<?php echo e($article->image_url); ?>" alt="<?php echo e($article->featured_image_alt); ?>" loading="lazy"/>
            </a>
            <div class="bldatebdg">
                <span class="bd"><?php echo e($article->published_at->format('d')); ?></span>
                <span class="bm"><?php echo e($article->published_at->translatedFormat('M')); ?></span>
            </div>
        </div>
        <div class="blbody">
            <div class="bltag"><?php echo e($article->category->name); ?></div>
            <div class="bltit"><a href="<?php echo e(route('articles.show', $article->slug)); ?>"><?php echo e($article->title); ?></a></div>
            <p class="blexc"><?php echo e(\Illuminate\Support\Str::limit($article->summary, 110)); ?></p>
            <div class="blmeta">
                <?php if($article->author): ?><span><i class="fas fa-user"></i><?php echo e($article->author->name); ?></span><?php endif; ?>
                <span><i class="fas fa-clock"></i><?php echo e($article->reading_minutes); ?> menit baca</span>
            </div>
            <a href="<?php echo e(route('articles.show', $article->slug)); ?>" class="blmore">Baca Selengkapnya <i class="fas fa-arrow-right"></i></a>
        </div>
    </div>
</div>
<?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/partials/article-card.blade.php ENDPATH**/ ?>