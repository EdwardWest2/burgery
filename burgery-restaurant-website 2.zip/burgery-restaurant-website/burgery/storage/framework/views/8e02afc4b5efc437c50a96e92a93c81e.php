<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="robots" content="noindex, nofollow">
    <title><?php echo $__env->yieldContent('title', 'Admin'); ?> - Admin <?php echo e(setting('brand_name', 'Burgery')); ?></title>
    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('favicon.svg')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@900&family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/all.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin.css')); ?>"/>
</head>
<body class="admin">
<?php
    $is = fn (string $pattern) => request()->routeIs($pattern);
?>
<div class="adm-wrap">
    <aside class="adm-side" id="admSide">
        <div class="adm-brand">
            <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(brand_wordmark()); ?></a>
            <small>PANEL ADMIN</small>
        </div>
        <nav class="adm-nav" aria-label="Menu admin">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e($is('admin.dashboard') ? 'active' : ''); ?>"><i class="fas fa-gauge"></i>Dashboard</a>

            <div class="grp">Konten</div>
            <a href="<?php echo e(route('admin.articles.index')); ?>" class="<?php echo e($is('admin.articles.*') ? 'active' : ''); ?>"><i class="fas fa-newspaper"></i>Artikel</a>
            <a href="<?php echo e(route('admin.article-categories.index')); ?>" class="<?php echo e($is('admin.article-categories.*') ? 'active' : ''); ?>"><i class="fas fa-tags"></i>Kategori Artikel</a>
            <a href="<?php echo e(route('admin.menu-items.index')); ?>" class="<?php echo e($is('admin.menu-items.*') ? 'active' : ''); ?>"><i class="fas fa-burger"></i>Menu</a>
            <a href="<?php echo e(route('admin.menu-categories.index')); ?>" class="<?php echo e($is('admin.menu-categories.*') ? 'active' : ''); ?>"><i class="fas fa-list"></i>Kategori Menu</a>
            <a href="<?php echo e(route('admin.gallery.index')); ?>" class="<?php echo e($is('admin.gallery.*') ? 'active' : ''); ?>"><i class="fas fa-images"></i>Galeri</a>
            <a href="<?php echo e(route('admin.pages.index')); ?>" class="<?php echo e($is('admin.pages.*') ? 'active' : ''); ?>"><i class="fas fa-file-lines"></i>Halaman</a>
            <a href="<?php echo e(route('admin.testimonials.index')); ?>" class="<?php echo e($is('admin.testimonials.*') ? 'active' : ''); ?>"><i class="fas fa-comments"></i>Testimoni</a>
            <a href="<?php echo e(route('admin.locations.index')); ?>" class="<?php echo e($is('admin.locations.*') ? 'active' : ''); ?>"><i class="fas fa-location-dot"></i>Lokasi</a>

            <div class="grp">Komunikasi</div>
            <a href="<?php echo e(route('admin.messages.index')); ?>" class="<?php echo e($is('admin.messages.*') ? 'active' : ''); ?>"><i class="fas fa-envelope"></i>Pesan Kontak
                <?php if($newMessageCount > 0): ?><span class="badge-n"><?php echo e($newMessageCount); ?></span><?php endif; ?>
            </a>

            <div class="grp">Sistem</div>
            <a href="<?php echo e(route('admin.settings.edit')); ?>" class="<?php echo e($is('admin.settings.*') ? 'active' : ''); ?>"><i class="fas fa-gear"></i>Pengaturan</a>
            <a href="<?php echo e(route('admin.profile.edit')); ?>" class="<?php echo e($is('admin.profile.*') ? 'active' : ''); ?>"><i class="fas fa-user"></i>Profil &amp; Password</a>
            <a href="<?php echo e(route('home')); ?>" target="_blank" rel="noopener"><i class="fas fa-arrow-up-right-from-square"></i>Lihat Website</a>
        </nav>
        <div class="adm-foot">
            <div class="who"><?php echo e(auth()->user()->name); ?></div>
            <form method="POST" action="<?php echo e(route('admin.logout')); ?>"><?php echo csrf_field(); ?><button type="submit"><i class="fas fa-right-from-bracket me-1"></i>Keluar</button></form>
        </div>
    </aside>

    <div class="adm-main">
        <header class="adm-top">
            <div class="d-flex align-items-center gap-3">
                <button class="adm-burger" id="admBurger" type="button" aria-label="Buka menu"><i class="fas fa-bars"></i></button>
                <h1><?php echo $__env->yieldContent('heading'); ?></h1>
            </div>
            <div><?php echo $__env->yieldContent('actions'); ?></div>
        </header>
        <div class="adm-body">
            <?php if(session('success')): ?><div class="flash ok" role="status"><i class="fas fa-check-circle me-1"></i><?php echo e(session('success')); ?></div><?php endif; ?>
            <?php if(session('error')): ?><div class="flash err" role="alert"><i class="fas fa-circle-exclamation me-1"></i><?php echo e(session('error')); ?></div><?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="flash err" role="alert">
                    <strong>Data belum tersimpan.</strong> Periksa isian berikut:
                    <ul class="mb-0 mt-1"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
                </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/admin.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/layouts/admin.blade.php ENDPATH**/ ?>