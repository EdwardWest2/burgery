<?php $isEdit = $item->exists; ?>
<?php $__env->startSection('title', $isEdit ? 'Edit Menu' : 'Tambah Menu'); ?>
<?php $__env->startSection('heading', $isEdit ? 'Edit Menu' : 'Tambah Menu'); ?>

<?php $__env->startSection('content'); ?>
<form method="POST" enctype="multipart/form-data" action="<?php echo e($isEdit ? route('admin.menu-items.update', $item) : route('admin.menu-items.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($isEdit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card-a">
                <div class="mb-3"><label class="form-label" for="name">Nama menu *</label><input id="name" name="name" class="form-control" value="<?php echo e(old('name', $item->name)); ?>" maxlength="150" required data-slug-source></div>
                <div class="mb-3"><label class="form-label" for="slug">Slug</label><input id="slug" name="slug" class="form-control" value="<?php echo e(old('slug', $item->slug)); ?>" maxlength="180" placeholder="dibuat otomatis dari nama" data-slug-target></div>
                <div class="mb-3"><label class="form-label" for="description">Deskripsi</label><textarea id="description" name="description" rows="5" class="form-control" maxlength="2000"><?php echo e(old('description', $item->description)); ?></textarea></div>
                <div class="row g-3">
                    <div class="col-md-6"><label class="form-label" for="menu_category_id">Kategori *</label>
                        <select id="menu_category_id" name="menu_category_id" class="form-select" required>
                            <option value="">Pilih kategori</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php if((int) old('menu_category_id', $item->menu_category_id) === $c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($categories->isEmpty()): ?><div class="hint text-danger"><a href="<?php echo e(route('admin.menu-categories.index')); ?>">Buat kategori menu dulu</a>.</div><?php endif; ?>
                    </div>
                    <div class="col-md-3"><label class="form-label" for="price">Harga (Rp) *</label><input id="price" name="price" type="number" min="0" step="1" class="form-control" value="<?php echo e(old('price', $item->price)); ?>" required><div class="hint">Angka bulat, tanpa titik.</div></div>
                    <div class="col-md-3"><label class="form-label" for="sort_order">Urutan</label><input id="sort_order" name="sort_order" type="number" min="0" class="form-control" value="<?php echo e(old('sort_order', $item->sort_order)); ?>"></div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card-a">
                <h2>Status</h2>
                <div class="form-check form-switch mb-2"><input class="form-check-input" type="checkbox" role="switch" name="is_available" id="is_available" value="1" <?php if(old('is_available', $item->is_available)): echo 'checked'; endif; ?>><label class="form-check-label" for="is_available">Tersedia</label></div>
                <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" role="switch" name="is_featured" id="is_featured" value="1" <?php if(old('is_featured', $item->is_featured)): echo 'checked'; endif; ?>><label class="form-check-label" for="is_featured">Menu unggulan (tampil di beranda)</label></div>
                <div class="d-grid gap-2"><button class="btn btn-brand" type="submit"><i class="fas fa-floppy-disk me-1"></i>Simpan</button><a class="btn btn-line" href="<?php echo e(route('admin.menu-items.index')); ?>">Batal</a></div>
            </div>
            <div class="card-a">
                <h2>Foto</h2>
                <img id="imgPrev" class="img-prev" src="<?php echo e($item->image ? $item->image_url : ''); ?>" alt="" style="<?php echo e($item->image ? '' : 'display:none'); ?>">
                <input class="form-control mb-2" type="file" name="image" accept="image/jpeg,image/png,image/webp" data-preview="imgPrev">
                <div class="hint mb-3">JPG, PNG, atau WebP, maks. 3 MB. Disarankan rasio 5:3.</div>
                <label class="form-label" for="image_alt">Alt text foto</label>
                <input id="image_alt" name="image_alt" class="form-control" value="<?php echo e(old('image_alt', $item->image_alt)); ?>" maxlength="200">
                <?php if($isEdit && $item->image): ?><div class="form-check mt-3"><input class="form-check-input" type="checkbox" name="remove_image" id="remove_image" value="1"><label class="form-check-label" for="remove_image">Hapus foto</label></div><?php endif; ?>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/admin/menu-items/form.blade.php ENDPATH**/ ?>