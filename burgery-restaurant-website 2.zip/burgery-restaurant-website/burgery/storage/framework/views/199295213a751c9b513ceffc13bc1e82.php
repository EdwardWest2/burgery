<?php $__env->startSection('og_type', 'website'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $hours = parse_hours(setting('opening_hours'));
    $firstHour = $hours[0] ?? null;
    $marquee = $categories->pluck('name')->merge($featured->pluck('name'))->unique()->values();
?>


<section id="hero">
    <div class="hs hs1"></div>
    <div class="hs hs2"></div>
    <div class="hbgtxt" aria-hidden="true">BURGER</div>
    <div class="container">
        <div class="row align-items-center g-5" style="min-height:88vh;">
            <div class="col-lg-6">
                <div class="hbadge">
                    <div class="hbi"><i class="fas fa-burger"></i></div>
                    <span><?php echo e(setting('hero_badge')); ?></span>
                </div>
                <h1 class="htitle"><?php echo e(highlight_text(setting('hero_title'), setting('hero_highlight'), 'hl')); ?></h1>
                <p class="hdesc"><?php echo e(setting('hero_text')); ?></p>
                <div class="d-flex flex-wrap gap-3 mb-2">
                    <a href="<?php echo e(route('menu.index')); ?>" class="btn-red"><i class="fas fa-utensils"></i>Lihat Menu</a>
                    <?php if(setting('video_url')): ?>
                        <a href="<?php echo e(setting('video_url')); ?>" class="magnific_popup btn-play popup-youtube">
                            <div class="pico"><i class="fas fa-play"></i></div>
                            <span>Tonton Cerita Kami</span>
                        </a>
                    <?php else: ?>
                        <a href="<?php echo e(route('about')); ?>" class="btn-play">
                            <div class="pico"><i class="fas fa-book-open"></i></div>
                            <span>Kenali Kami</span>
                        </a>
                    <?php endif; ?>
                </div>
                <div class="hstats d-flex gap-3 flex-wrap mt-4">
                    <div class="hstat"><span class="snum"><?php echo e($stats['menus']); ?></span><small>Pilihan Menu</small></div>
                    <div class="sdiv"></div>
                    <div class="hstat"><span class="snum"><?php echo e($stats['categories']); ?></span><small>Kategori</small></div>
                    <div class="sdiv"></div>
                    <div class="hstat"><span class="snum"><?php echo e($stats['articles']); ?></span><small>Artikel</small></div>
                </div>
            </div>
            <div class="col-lg-6">
                <div style="position:relative;text-align:center;">
                    <div class="hcircle">
                        <img src="<?php echo e(asset('assets/img/banner-img.jpg')); ?>" alt="Burger dengan dua patty, keju, selada, dan tomat"/>
                    </div>
                    <div class="fcard fc1">
                        <div class="fcoi r"><i class="fas fa-fire"></i></div>
                        <div><span class="fcnum"><?php echo e($stats['menus']); ?> Menu</span><span class="fcsm"><?php echo e($stats['categories']); ?> kategori</span></div>
                    </div>
                    <?php if($firstHour): ?>
                    <div class="fcard fc2">
                        <div class="fcoi y"><i class="fas fa-clock"></i></div>
                        <div><span class="fcnum"><?php echo e($firstHour['time'] ?: 'Jam buka'); ?></span><span class="fcsm"><?php echo e($firstHour['label']); ?></span></div>
                    </div>
                    <?php endif; ?>
                    <div class="fcard fc3">
                        <div class="fcoi g"><i class="fas fa-location-dot"></i></div>
                        <div><span class="fcnum"><?php echo e(setting('city') ?: 'Kunjungi kami'); ?></span><span class="fcsm"><a href="<?php echo e(route('contact')); ?>" style="color:inherit;">Lihat lokasi</a></span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php if($marquee->isNotEmpty()): ?>
<div class="mqsec" aria-hidden="true">
    <div class="mqtrack">
        <?php for($i = 0; $i < 2; $i++): ?>
            <?php $__currentLoopData = $marquee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mqitem"><i class="fas fa-circle"></i><?php echo e($name); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endfor; ?>
    </div>
</div>
<?php endif; ?>


<?php if($categories->isNotEmpty()): ?>
<section id="category">
    <div class="container">
        <div class="text-center mb-5" data-aos="fade-up">
            <span class="slbl">Yang Kami Sajikan</span>
            <h2 class="stitle">Jelajahi <span>Kategori</span> Menu</h2>
            <div class="sline"></div>
        </div>
        <div class="row g-3 justify-content-center">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $thumb = $cat->items->sortBy('sort_order')->first(); ?>
                <div class="col-6 col-sm-4 col-md-3 col-lg-2" data-aos="zoom-in" data-aos-delay="<?php echo e($i * 70); ?>">
                    <a class="catcard d-block" href="<?php echo e(route('menu.index', ['kategori' => $cat->slug])); ?>">
                        <img class="catimg" src="<?php echo e(media_url($thumb?->image, 'assets/img/menu/1.jpg')); ?>" alt=""/>
                        <div class="catnm"><?php echo e($cat->name); ?></div>
                        <div class="catct"><?php echo e($cat->items_count); ?> menu</div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>


<section id="about">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-5" data-aos="fade-right">
                <div class="astack">
                    <div class="aexp"><span class="anum"><?php echo e($stats['menus']); ?></span><small>Pilihan<br/>Menu</small></div>
                    <div class="amain"><img src="<?php echo e(asset('assets/img/about1.jpg')); ?>" alt="Ruang makan restoran" loading="lazy"/></div>
                    <div class="asm"><img src="<?php echo e(asset('assets/img/about2.jpg')); ?>" alt="Hidangan di atas meja" loading="lazy"/></div>
                </div>
            </div>
            <div class="col-lg-7" data-aos="fade-left">
                <span class="slbl">Cerita Kami</span>
                <h2 class="stitle text-start"><?php echo e(setting('about_heading')); ?></h2>
                <div class="sline lft"></div>
                <p class="sdesc mb-4"><?php echo e(setting('about_text')); ?></p>
                <div class="mb-4">
                    <?php $__currentLoopData = [['leaf', 'r', 1], ['award', 'y', 2], ['heart', 'g', 3]]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$icon, $tone, $n]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="fti">
                            <div class="ftico <?php echo e($tone); ?>"><i class="fas fa-<?php echo e($icon === 'heart' ? 'heart' : $icon); ?>"></i></div>
                            <div>
                                <h6><?php echo e(setting('adv_'.$n.'_title')); ?></h6>
                                <p><?php echo e(setting('adv_'.$n.'_text')); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <a href="<?php echo e(route('about')); ?>" class="btn-red"><i class="fas fa-book-open"></i>Baca Selengkapnya</a>
            </div>
        </div>
    </div>
</section>


<section id="menu">
    <div class="container">
        <div class="text-center mb-5" data-aos="fade-up">
            <span class="slbl">Pilihan Kami</span>
            <h2 class="stitle">Menu <span>Unggulan</span></h2>
            <div class="sline"></div>
        </div>
        <?php if($featured->isEmpty()): ?>
            <p class="text-center sdesc">Menu akan segera hadir.</p>
        <?php else: ?>
            <div class="row g-4" id="mgrid">
                <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials.menu-card', ['item' => $item, 'delay' => $i % 3], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="text-center mt-5"><a href="<?php echo e(route('menu.index')); ?>" class="btn-red"><i class="fas fa-th-large"></i>Lihat Semua Menu</a></div>
        <?php endif; ?>
    </div>
</section>


<?php if($gallery->isNotEmpty()): ?>
<section id="gallery">
    <div class="container">
        <div class="text-center mb-5" data-aos="fade-up">
            <span class="slbl">Galeri</span>
            <h2 class="stitle">Sekilas <span>Burgery</span></h2>
            <div class="sline"></div>
        </div>
        <div class="ggrid" data-aos="fade-up">
            <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" class="gitem" data-gi="<?php echo e($i); ?>"
                    data-gimg="<?php echo e($photo->image_url); ?>"
                    data-gtitle="<?php echo e($photo->caption); ?>"
                    data-gdesc="<?php echo e($photo->alt_text); ?>">
                    <img src="<?php echo e($photo->image_url); ?>" alt="<?php echo e($photo->alt_text ?: $photo->caption); ?>" loading="lazy"/>
                    <div class="gover"><span><i class="fas fa-expand-alt"></i> <?php echo e($photo->caption ?: 'Perbesar'); ?></span></div>
                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="text-center mt-5"><a href="<?php echo e(route('gallery')); ?>" class="btn-red"><i class="fas fa-images"></i>Lihat Galeri</a></div>
    </div>
</section>
<?php echo $__env->make('partials.gallery-popup', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>


<?php if($testimonials->isNotEmpty()): ?>
<section id="testimonials">
    <div class="container">
        <div class="text-center mb-5" data-aos="fade-up">
            <span class="slbl">Kata Mereka</span>
            <h2 class="stitle">Ulasan <span>Pelanggan</span></h2>
            <div class="sline"></div>
        </div>
        <div class="swiper tesSwiper" data-aos="fade-up">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide">
                        <div class="tescard">
                            <div class="tesq" aria-hidden="true">&ldquo;</div>
                            <p class="testxt"><?php echo e($t->content); ?></p>
                            <div class="tesauth">
                                <span class="tesinit" aria-hidden="true"><?php echo e(mb_strtoupper(mb_substr($t->name, 0, 1))); ?></span>
                                <div>
                                    <div class="tesnm"><?php echo e($t->name); ?></div>
                                    <?php if($t->role): ?><div class="tesrl"><?php echo e($t->role); ?></div><?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="swiper-pagination mt-4" style="position:static;"></div>
        </div>
    </div>
</section>
<?php endif; ?>


<section id="hours">
    <div class="hrsbg"></div>
    <div class="container" style="position:relative;z-index:2;">
        <div class="text-center mb-5" data-aos="fade-up">
            <span class="slbl" style="color:#a5d6bc;">Jam Operasional</span>
            <h2 class="stitle" style="color:#fff;">Kami Siap <span style="color:var(--secondary);">Menyambut Anda</span></h2>
            <div class="sline"></div>
        </div>
        <div class="row g-4 align-items-start justify-content-center">
            <div class="col-lg-5" data-aos="fade-right">
                <div class="hrscard">
                    <?php $__empty_1 = true; $__currentLoopData = $hours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="hrsrow">
                            <span class="hrsday"><i class="fas fa-calendar-day me-2" style="color:var(--secondary);"></i><?php echo e($h['label']); ?></span>
                            <div class="d-flex align-items-center gap-2">
                                <div class="hdot <?php echo e($h['closed'] ? 'off' : 'on'); ?>"></div>
                                <span class="hrstime" <?php if($h['closed']): ?> style="color:#ff6b6b;" <?php endif; ?>><?php echo e($h['time']); ?></span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="hrsrow"><span class="hrsday">Jam operasional belum diatur.</span></div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-3" data-aos="zoom-in">
                <div class="hrscta">
                    <i class="fas fa-envelope-open-text fa-2x mb-3" style="color:rgba(255,255,255,.8);"></i>
                    <h4>Ada Pertanyaan?</h4>
                    <p>Kirim pesan, kami akan membalas secepatnya.</p>
                    <a href="<?php echo e(route('contact')); ?>" class="btnw">Hubungi Kami</a>
                </div>
            </div>
            <div class="col-lg-4" data-aos="fade-left">
                <div class="hrscard">
                    <h5 style="color:#fff;margin-bottom:18px;font-family:'Poppins',sans-serif;font-size:.95rem;font-weight:700;"><i class="fas fa-map-marker-alt me-2" style="color:var(--secondary);"></i>Temukan Kami</h5>
                    <?php if(setting('address')): ?><div class="hrsrow"><span class="hrsday"><i class="fas fa-location-dot me-2" style="color:var(--secondary);"></i>Alamat</span><span class="hrstime" style="font-size:.8rem;text-align:right;"><?php echo e(setting('address')); ?></span></div><?php endif; ?>
                    <?php if(setting('phone')): ?><div class="hrsrow"><span class="hrsday"><i class="fas fa-phone me-2" style="color:var(--secondary);"></i>Telepon</span><span class="hrstime" style="font-size:.8rem;"><?php echo e(setting('phone')); ?></span></div><?php endif; ?>
                    <?php if(setting('email')): ?><div class="hrsrow"><span class="hrsday"><i class="fas fa-envelope me-2" style="color:var(--secondary);"></i>Email</span><span class="hrstime" style="font-size:.8rem;"><?php echo e(setting('email')); ?></span></div><?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>


<?php if($articles->isNotEmpty()): ?>
<section id="blog">
    <div class="container">
        <div class="text-center mb-5" data-aos="fade-up">
            <span class="slbl">Kabar &amp; Cerita</span>
            <h2 class="stitle">Artikel <span>Terbaru</span></h2>
            <div class="sline"></div>
        </div>
        <div class="row g-4">
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials.article-card', ['article' => $article, 'delay' => $i], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="text-center mt-5"><a href="<?php echo e(route('articles.index')); ?>" class="btn-red"><i class="fas fa-newspaper"></i>Semua Artikel</a></div>
    </div>
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/site/home.blade.php ENDPATH**/ ?>