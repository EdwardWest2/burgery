<div class="col-sm-6 col-lg-4 mwrap" data-aos="fade-up" data-aos-delay="<?php echo e(($delay ?? 0) * 80); ?>">
    <a href="<?php echo e(route('menu.show', $item->slug)); ?>" class="mcard mcard-link">
        <div class="mimg">
            <img src="<?php echo e($item->image_url); ?>" alt="<?php echo e($item->image_alt ?: $item->name); ?>" loading="lazy"/>
            <?php if(! $item->is_available): ?>
                <div class="mbdg sold">Sedang habis</div>
            <?php elseif($item->is_featured): ?>
                <div class="mbdg hot"><i class="fas fa-star"></i> Unggulan</div>
            <?php endif; ?>
        </div>
        <div class="mbody">
            <div class="mcat"><?php echo e($item->category->name); ?></div>
            <div class="mtit"><?php echo e($item->name); ?></div>
            <div class="mdesc"><?php echo e(\Illuminate\Support\Str::limit((string) $item->description, 95)); ?></div>
            <div class="mfoot">
                <div class="mprice"><?php echo e($item->price_label); ?></div>
                <span class="madd" aria-hidden="true"><i class="fas fa-arrow-right"></i></span>
            </div>
        </div>
    </a>
</div>
<?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/partials/menu-card.blade.php ENDPATH**/ ?>