<?php
    $hours = parse_hours(setting('opening_hours'));
    $firstHour = $hours[0] ?? null;
    $logo = setting('logo');
    $isHome = request()->routeIs('home');
?>
<a class="skip-link" href="#main">Lewati ke konten</a>

<div id="topbar">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
            <div class="top-contact d-flex flex-wrap">
                <?php if(setting('phone')): ?><span><i class="fas fa-phone-alt"></i><?php echo e(setting('phone')); ?></span><?php endif; ?>
                <?php if(setting('email')): ?><span><i class="fas fa-envelope"></i><?php echo e(setting('email')); ?></span><?php endif; ?>
                <?php if(setting('address')): ?><span class="d-none d-md-inline"><i class="fas fa-map-marker-alt"></i><?php echo e(\Illuminate\Support\Str::limit(setting('address'), 60)); ?></span><?php endif; ?>
            </div>
            <div class="d-flex align-items-center gap-3">
                <?php if($firstHour): ?>
                    <span class="ttag d-none d-sm-inline"><i class="fas fa-clock me-1"></i><?php echo e($firstHour['label']); ?>: <?php echo e($firstHour['time']); ?></span>
                <?php endif; ?>
                <div class="tsoc">
                    <?php $__currentLoopData = social_links(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($s['url']); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo e($s['label']); ?>"><i class="<?php echo e($s['icon']); ?>"></i></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<nav class="navbar navbar-expand-lg" id="nav" aria-label="Navigasi utama">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
            <div class="blogo">
                <?php if($logo): ?>
                    <img src="<?php echo e(media_url($logo)); ?>" alt="" class="blogo-img">
                <?php else: ?>
                    <div class="bico"><i class="fas fa-burger"></i></div>
                <?php endif; ?>
                <div>
                    <div class="bname"><?php echo e(brand_wordmark()); ?></div>
                    <div class="bsub"><?php echo e(setting('brand_tagline')); ?></div>
                </div>
            </div>
        </a>
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navmenu" aria-controls="navmenu" aria-expanded="false" aria-label="Buka menu navigasi">
            <i class="fas fa-bars" style="color:var(--primary);font-size:1.35rem;"></i>
        </button>
        <div class="collapse navbar-collapse" id="navmenu">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Beranda</a></li>
                <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('about') ? 'active' : ''); ?>" href="<?php echo e(route('about')); ?>">Tentang Kami</a></li>
                <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('menu.*') ? 'active' : ''); ?>" href="<?php echo e(route('menu.index')); ?>">Menu</a></li>
                <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('articles.*') ? 'active' : ''); ?>" href="<?php echo e(route('articles.index')); ?>">Artikel</a></li>
                <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('gallery') ? 'active' : ''); ?>" href="<?php echo e(route('gallery')); ?>">Galeri</a></li>
                <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>" href="<?php echo e(route('contact')); ?>">Kontak</a></li>
            </ul>
            <div class="d-flex align-items-center gap-1">
                <button id="navSearchBtn" type="button" title="Cari menu" aria-label="Cari menu"><i class="fas fa-search"></i></button>
                <a href="<?php echo e(route('menu.index')); ?>" class="nav-link nav-cta"><i class="fas fa-book-open me-1"></i>Lihat Menu</a>
            </div>
        </div>
    </div>
</nav>

<div id="searchOv" role="dialog" aria-modal="true" aria-label="Cari menu">
    <button class="sovclose" id="searchClose" type="button" aria-label="Tutup"><i class="fas fa-times"></i></button>
    <div class="sovbox">
        <h4>Mau makan apa hari ini?</h4>
        <form action="<?php echo e(route('menu.index')); ?>" method="GET" class="sovinput">
            <input type="text" name="q" id="searchInput" placeholder="Cari nama menu..." autocomplete="off" maxlength="100"/>
            <button type="submit" aria-label="Cari"><i class="fas fa-search"></i></button>
        </form>
        <div class="sovcats">
            <a class="sovcat" href="<?php echo e(route('menu.index')); ?>"><img src="<?php echo e(asset('assets/img/menu/1.jpg')); ?>" alt=""/>Semua Menu</a>
            <?php $__currentLoopData = $navCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="sovcat" href="<?php echo e(route('menu.index', ['kategori' => $c->slug])); ?>"><?php echo e($c->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/partials/header.blade.php ENDPATH**/ ?>