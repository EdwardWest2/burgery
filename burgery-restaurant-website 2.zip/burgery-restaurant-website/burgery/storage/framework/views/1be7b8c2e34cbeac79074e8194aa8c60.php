<?php $__env->startSection('title', 'Pengaturan'); ?>
<?php $__env->startSection('heading', 'Pengaturan Website'); ?>

<?php $__env->startSection('content'); ?>
<form method="POST" enctype="multipart/form-data" action="<?php echo e(route('admin.settings.update')); ?>">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <p class="hint mb-3">Mengosongkan kolom bertipe teks utama akan mengembalikan teks bawaan; kolom kontak/sosial yang dikosongkan akan disembunyikan dari website.</p>
    <?php $__currentLoopData = $schema; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupKey => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card-a">
            <h2><?php echo e($group['label']); ?></h2>
            <div class="row g-3">
                <?php $__currentLoopData = $group['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $val = old($key, $values[$key] ?? $f['default']); ?>
                    <div class="<?php echo e(in_array($f['type'], ['textarea', 'image']) ? 'col-12' : 'col-md-6'); ?>">
                        <label class="form-label" for="<?php echo e($key); ?>"><?php echo e($f['label']); ?></label>
                        <?php if($f['type'] === 'textarea'): ?>
                            <textarea id="<?php echo e($key); ?>" name="<?php echo e($key); ?>" rows="<?php echo e($key === 'opening_hours' ? 5 : 3); ?>" class="form-control" maxlength="2000"><?php echo e($val); ?></textarea>
                        <?php elseif($f['type'] === 'image'): ?>
                            <?php if($val): ?><img id="prev-<?php echo e($key); ?>" class="img-prev" src="<?php echo e(media_url($val)); ?>" alt="" style="max-height:80px"><?php else: ?><img id="prev-<?php echo e($key); ?>" class="img-prev" src="" alt="" style="display:none;max-height:80px"><?php endif; ?>
                            <input id="<?php echo e($key); ?>" type="file" name="<?php echo e($key); ?>" class="form-control" accept="image/jpeg,image/png,image/webp" data-preview="prev-<?php echo e($key); ?>">
                            <?php if($val): ?><div class="form-check mt-2"><input class="form-check-input" type="checkbox" name="remove_logo" id="remove_logo" value="1"><label class="form-check-label" for="remove_logo">Hapus logo</label></div><?php endif; ?>
                        <?php else: ?>
                            <input id="<?php echo e($key); ?>" name="<?php echo e($key); ?>" type="<?php echo e($f['type'] === 'text' ? 'text' : $f['type']); ?>" class="form-control" value="<?php echo e($val); ?>" maxlength="255">
                        <?php endif; ?>
                        <?php if(isset($f['help'])): ?><div class="hint"><?php echo e($f['help']); ?></div><?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <button class="btn btn-brand" type="submit"><i class="fas fa-floppy-disk me-1"></i>Simpan pengaturan</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/admin/settings/edit.blade.php ENDPATH**/ ?>