<?php $__env->startSection('title', 'Artikel'); ?>
<?php $__env->startSection('heading', 'Artikel'); ?>
<?php $__env->startSection('actions'); ?><a href="<?php echo e(route('admin.articles.create')); ?>" class="btn btn-brand btn-sm"><i class="fas fa-plus me-1"></i>Artikel baru</a><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card-a">
    <form method="GET" class="row g-2 mb-3">
        <div class="col-md-5"><input type="search" name="q" value="<?php echo e($filters['search']); ?>" class="form-control" placeholder="Cari judul artikel..."></div>
        <div class="col-6 col-md-3">
            <select name="status" class="form-select" aria-label="Status">
                <option value="">Semua status</option>
                <option value="published" <?php if($filters['status'] === 'published'): echo 'selected'; endif; ?>>Published</option>
                <option value="draft" <?php if($filters['status'] === 'draft'): echo 'selected'; endif; ?>>Draft</option>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <select name="category" class="form-select" aria-label="Kategori">
                <option value="">Semua kategori</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php if($filters['category'] === $c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-2 d-flex gap-2"><button class="btn btn-line flex-fill" type="submit">Cari</button><?php if($filters['search'] || $filters['status'] || $filters['category']): ?><a href="<?php echo e(route('admin.articles.index')); ?>" class="btn btn-line">Reset</a><?php endif; ?></div>
    </form>

    <?php if($articles->isEmpty()): ?>
        <div class="empty-a"><i class="fas fa-newspaper"></i>
            <?php echo e(($filters['search'] || $filters['status'] || $filters['category']) ? 'Tidak ada artikel yang cocok.' : 'Belum ada artikel.'); ?>

            <div class="mt-3"><a class="btn btn-brand btn-sm" href="<?php echo e(route('admin.articles.create')); ?>">Tulis artikel</a></div>
        </div>
    <?php else: ?>
        <div class="tbl-wrap"><table class="tbl">
            <thead><tr><th></th><th>Judul</th><th>Kategori</th><th>Penulis</th><th>Status</th><th>Tanggal terbit</th><th></th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><img class="thumb" src="<?php echo e($a->image_url); ?>" alt=""></td>
                    <td><div class="title"><?php echo e($a->title); ?> <?php if($a->is_featured): ?><i class="fas fa-star" style="color:var(--secondary);" title="Artikel unggulan"></i><?php endif; ?></div><div class="sub">/artikel/<?php echo e($a->slug); ?></div></td>
                    <td><?php echo e($a->category->name); ?></td>
                    <td><?php echo e($a->author?->name ?? '-'); ?></td>
                    <td><?php echo $__env->make('admin.partials.article-status', ['article' => $a], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                    <td class="sub"><?php echo e($a->published_at?->translatedFormat('j M Y H:i') ?? '-'); ?></td>
                    <td class="acts">
                        <a class="btn-line btn-sm-x" href="<?php echo e(route('admin.articles.edit', $a)); ?>">Edit</a>
                        <a class="btn-line btn-sm-x" href="<?php echo e(route('admin.articles.preview', $a)); ?>" target="_blank" rel="noopener">Pratinjau</a>
                        <?php echo $__env->make('admin.partials.delete-form', ['action' => route('admin.articles.destroy', $a), 'confirm' => 'Hapus artikel "'.$a->title.'"? Tindakan ini tidak dapat dibatalkan.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table></div>
        <div class="mt-3"><?php echo e($articles->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/admin/articles/index.blade.php ENDPATH**/ ?>