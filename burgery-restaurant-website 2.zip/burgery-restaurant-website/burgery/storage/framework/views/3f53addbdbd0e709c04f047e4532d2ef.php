<?php $__env->startSection('title', $item->name); ?>
<?php $__env->startSection('description', \Illuminate\Support\Str::limit(strip_tags((string) $item->description), 155) ?: $item->name.' di '.setting('brand_name')); ?>
<?php $__env->startSection('image', $item->image_url); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.page-header', ['heading' => $item->name, 'crumbs' => ['Menu' => route('menu.index'), $item->category->name => route('menu.index', ['kategori' => $item->category->slug]), $item->name => null]], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<section class="pgbody">
    <div class="container">
        <div class="row g-5 align-items-center">
            <div class="col-lg-6" data-aos="fade-right">
                <div class="mdetimg">
                    <img src="<?php echo e($item->image_url); ?>" alt="<?php echo e($item->image_alt ?: $item->name); ?>"/>
                </div>
            </div>
            <div class="col-lg-6" data-aos="fade-left">
                <a class="mcat" href="<?php echo e(route('menu.index', ['kategori' => $item->category->slug])); ?>"><?php echo e($item->category->name); ?></a>
                <h2 class="stitle text-start mt-1"><?php echo e($item->name); ?></h2>
                <div class="sline lft"></div>
                <div class="mdetprice"><?php echo e($item->price_label); ?></div>
                <div class="mdetstat <?php echo e($item->is_available ? 'ok' : 'no'); ?>">
                    <i class="fas <?php echo e($item->is_available ? 'fa-circle-check' : 'fa-ban'); ?>"></i>
                    <?php echo e($item->is_available ? 'Tersedia' : 'Sedang habis'); ?>

                    <?php if($item->is_featured): ?><span class="mdetfeat"><i class="fas fa-star"></i> Menu unggulan</span><?php endif; ?>
                </div>
                <?php if($item->description): ?><p class="sdesc mb-4"><?php echo e($item->description); ?></p><?php endif; ?>
                <p class="sdesc small mb-4">Ingin datang atau bertanya tentang menu ini? Lihat lokasi dan jam buka kami.</p>
                <div class="d-flex flex-wrap gap-3">
                    <a href="<?php echo e(route('contact')); ?>" class="btn-red"><i class="fas fa-location-dot"></i>Lokasi &amp; Kontak</a>
                    <a href="<?php echo e(route('menu.index', ['kategori' => $item->category->slug])); ?>" class="btn-red btn-ghost"><i class="fas fa-th-large"></i>Menu <?php echo e($item->category->name); ?></a>
                </div>
            </div>
        </div>

        <?php if($related->isNotEmpty()): ?>
            <div class="text-center mt-5 pt-4 mb-4">
                <span class="slbl">Mungkin Anda Suka</span>
                <h3 class="stitle">Menu Serupa</h3>
                <div class="sline"></div>
            </div>
            <div class="row g-4">
                <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials.menu-card', ['item' => $r, 'delay' => $i], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/site/menu/show.blade.php ENDPATH**/ ?>