<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php
        $brand = setting('brand_name', 'Burgery');
        $pageTitle = trim($__env->yieldContent('title'));
        $pageDesc = trim($__env->yieldContent('description')) ?: setting('seo_default_description');
        $fullTitle = $pageTitle !== '' ? $pageTitle.' - '.$brand : setting('seo_default_title');
        $ogImage = trim($__env->yieldContent('image'));
    ?>
    <title><?php echo e($fullTitle); ?></title>
    <meta name="description" content="<?php echo e($pageDesc); ?>">
    <meta name="author" content="<?php echo e($brand); ?>">
    <meta property="og:site_name" content="<?php echo e($brand); ?>">
    <meta property="og:title" content="<?php echo e($fullTitle); ?>">
    <meta property="og:description" content="<?php echo e($pageDesc); ?>">
    <meta property="og:type" content="<?php echo $__env->yieldContent('og_type', 'website'); ?>">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    <?php if($ogImage !== ''): ?><meta property="og:image" content="<?php echo e($ogImage); ?>"><?php endif; ?>
    <?php echo $__env->yieldContent('head'); ?>
    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('favicon.svg')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Poppins:wght@300;400;500;600;700&family=Dancing+Script:wght@700&display=swap" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/css/aos.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/css/swiper-bundle.min.css')); ?>" rel="stylesheet"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/all.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/magnific-popup.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/burgery.css')); ?>"/>
</head>
<body>
<?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php if(isset($preview) && $preview): ?>
    <div class="preview-bar">
        <i class="fas fa-eye"></i> Mode pratinjau admin: halaman ini
        <?php echo e($article->isLive() ? 'sudah tayang.' : 'belum tayang untuk publik.'); ?>

        <a href="<?php echo e(route('admin.articles.edit', $article)); ?>">Kembali ke editor</a>
    </div>
<?php endif; ?>

<main id="main">
    <?php echo $__env->yieldContent('content'); ?>
</main>

<?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<button id="btt" type="button" aria-label="Kembali ke atas"><i class="fas fa-chevron-up"></i></button>

<script src="<?php echo e(asset('assets/js/jquery-3.7.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/aos.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/layouts/app.blade.php ENDPATH**/ ?>