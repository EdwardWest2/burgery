<?php $__env->startSection('title', 'Kontak & Lokasi'); ?>
<?php $__env->startSection('description', 'Alamat, jam operasional, dan formulir kontak '.setting('brand_name').'.'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.page-header', ['heading' => 'Kontak & Lokasi', 'crumbs' => ['Kontak' => null], 'lead' => 'Punya pertanyaan, kritik, atau rencana acara? Kirim pesan kepada kami.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $hours = parse_hours(setting('opening_hours')); ?>
<section id="contact-section" class="pgbody">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4" data-aos="fade-right">
                <div class="ctdark">
                    <h4>Informasi</h4>
                    <p class="ctsub">Pesan ini hanya untuk komunikasi, bukan untuk memesan makanan.</p>
                    <?php if(setting('address')): ?>
                    <div class="ctitem">
                        <div class="cticon"><i class="fas fa-map-marker-alt"></i></div>
                        <div class="ctinfo"><strong>Alamat</strong><span><?php echo nl2br(e(setting('address'))); ?></span></div>
                    </div>
                    <?php endif; ?>
                    <?php if(setting('phone')): ?>
                    <div class="ctitem">
                        <div class="cticon"><i class="fas fa-phone-alt"></i></div>
                        <div class="ctinfo"><strong>Telepon</strong><span><?php echo e(setting('phone')); ?></span></div>
                    </div>
                    <?php endif; ?>
                    <?php if(setting('email')): ?>
                    <div class="ctitem">
                        <div class="cticon"><i class="fas fa-envelope"></i></div>
                        <div class="ctinfo"><strong>Email</strong><span><?php echo e(setting('email')); ?></span></div>
                    </div>
                    <?php endif; ?>
                    <?php if($hours): ?>
                    <div class="ctitem">
                        <div class="cticon"><i class="fas fa-clock"></i></div>
                        <div class="ctinfo"><strong>Jam operasional</strong><span><?php $__currentLoopData = $hours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($h['label']); ?><?php if($h['time']): ?>: <?php echo e($h['time']); ?><?php endif; ?><br/><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></span></div>
                    </div>
                    <?php endif; ?>
                    <?php if(social_links()): ?>
                    <div class="ctsocrow">
                        <?php $__currentLoopData = social_links(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($s['url']); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo e($s['label']); ?>"><i class="<?php echo e($s['icon']); ?>"></i></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-lg-8" data-aos="fade-left">
                <div class="formcard" id="form">
                    <?php if(session('success')): ?>
                        <div class="formalert ok" role="status"><i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="formalert err" role="alert"><i class="fas fa-circle-exclamation"></i> Pesan belum terkirim. Periksa isian yang ditandai.</div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('contact.store')); ?>" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="row g-3">
                            <div class="col-sm-6">
                                <label class="flbl" for="c-name">Nama *</label>
                                <input id="c-name" type="text" name="name" class="fctrl <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-bad <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>" maxlength="100" required>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="ferr"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-sm-6">
                                <label class="flbl" for="c-email">Email *</label>
                                <input id="c-email" type="email" name="email" class="fctrl <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-bad <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" maxlength="150" required>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="ferr"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-sm-6">
                                <label class="flbl" for="c-phone">Nomor telepon</label>
                                <input id="c-phone" type="tel" name="phone" class="fctrl <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-bad <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('phone')); ?>" maxlength="40">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="ferr"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-sm-6">
                                <label class="flbl" for="c-subject">Subjek *</label>
                                <select id="c-subject" name="subject" class="fctrl <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-bad <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <?php $__currentLoopData = \App\Http\Requests\ContactRequest::SUBJECTS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($s); ?>" <?php if(old('subject') === $s): echo 'selected'; endif; ?>><?php echo e($s); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="ferr"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12">
                                <label class="flbl" for="c-message">Pesan *</label>
                                <textarea id="c-message" name="message" rows="5" class="fctrl <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-bad <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" maxlength="3000" required><?php echo e(old('message')); ?></textarea>
                                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="ferr"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="hp-field" aria-hidden="true">
                                <label for="c-website">Jangan diisi</label>
                                <input id="c-website" type="text" name="website" tabindex="-1" autocomplete="off">
                            </div>
                            <div class="col-12"><button class="btn-red" type="submit"><i class="fas fa-paper-plane"></i>Kirim Pesan</button></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <?php if($locations->isNotEmpty()): ?>
            <div class="text-center mt-5 pt-4 mb-4">
                <span class="slbl">Lokasi</span>
                <h3 class="stitle">Temukan Kami</h3>
                <div class="sline"></div>
            </div>
            <div class="row g-4 justify-content-center">
                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="loccard">
                            <h5><?php echo e($loc->name); ?></h5>
                            <p><i class="fas fa-location-dot"></i><?php echo nl2br(e($loc->address)); ?></p>
                            <?php if($loc->phone): ?><p><i class="fas fa-phone"></i><?php echo e($loc->phone); ?></p><?php endif; ?>
                            <?php if($loc->opening_hours): ?><p><i class="fas fa-clock"></i><?php echo nl2br(e($loc->opening_hours)); ?></p><?php endif; ?>
                            <?php if($loc->map_url): ?><a href="<?php echo e($loc->map_url); ?>" target="_blank" rel="noopener noreferrer" class="blmore">Buka di peta <i class="fas fa-arrow-right"></i></a><?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/site/contact.blade.php ENDPATH**/ ?>