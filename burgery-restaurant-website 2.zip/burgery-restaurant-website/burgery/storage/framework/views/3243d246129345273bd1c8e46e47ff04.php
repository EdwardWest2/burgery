
<section class="pghead">
    <div class="container">
        <nav aria-label="Breadcrumb">
            <ol class="pgcrumb">
                <li><a href="<?php echo e(route('home')); ?>">Beranda</a></li>
                <?php $__currentLoopData = $crumbs ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php if($url): ?><a href="<?php echo e($url); ?>"><?php echo e($label); ?></a><?php else: ?><span aria-current="page"><?php echo e($label); ?></span><?php endif; ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
        </nav>
        <h1 class="pgtitle"><?php echo e($heading); ?></h1>
        <?php if(isset($lead)): ?><p class="pglead"><?php echo e($lead); ?></p><?php endif; ?>
    </div>
</section>
<?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/partials/page-header.blade.php ENDPATH**/ ?>