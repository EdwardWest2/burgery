<form method="POST" action="<?php echo e($action); ?>" data-confirm="<?php echo e($confirm); ?>">
    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
    <button type="submit" class="btn-danger-x"><i class="fas fa-trash"></i> <?php echo e($label ?? 'Hapus'); ?></button>
</form>
<?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/admin/partials/delete-form.blade.php ENDPATH**/ ?>