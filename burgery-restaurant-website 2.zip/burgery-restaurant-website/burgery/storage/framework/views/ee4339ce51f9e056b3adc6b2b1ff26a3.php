<?php if($article->status === 'draft'): ?>
    <span class="pill draft">Draft</span>
<?php elseif($article->isScheduled()): ?>
    <span class="pill scheduled" title="Tayang otomatis pada <?php echo e($article->published_at->translatedFormat('j M Y H:i')); ?>">Terjadwal</span>
<?php else: ?>
    <span class="pill published">Published</span>
<?php endif; ?>
<?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/admin/partials/article-status.blade.php ENDPATH**/ ?>