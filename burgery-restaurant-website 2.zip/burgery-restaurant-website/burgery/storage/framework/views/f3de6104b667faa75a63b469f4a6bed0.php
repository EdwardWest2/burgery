<?php $__env->startSection('title', 'Testimoni'); ?>
<?php $__env->startSection('heading', 'Testimoni'); ?>
<?php $__env->startSection('actions'); ?><a href="<?php echo e(route('admin.testimonials.create')); ?>" class="btn btn-brand btn-sm"><i class="fas fa-plus me-1"></i>Tambah testimoni</a><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card-a">
    <div class="flash err" style="background:#fff7e6;border-color:#f6d9a0;color:#7a5200;"><i class="fas fa-triangle-exclamation me-1"></i>Testimoni bawaan adalah <strong>contoh teks</strong>. Ganti dengan ulasan pelanggan asli (dengan izin mereka) atau nonaktifkan semuanya agar bagian ini tersembunyi di beranda.</div>
    <?php if($testimonials->isEmpty()): ?>
        <div class="empty-a"><i class="fas fa-comments"></i>Belum ada testimoni. Bagian testimoni di beranda tersembunyi.</div>
    <?php else: ?>
        <div class="tbl-wrap"><table class="tbl">
            <thead><tr><th>Nama</th><th>Isi</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="title"><?php echo e($t->name); ?><div class="sub"><?php echo e($t->role); ?></div></td>
                    <td class="sub"><?php echo e(\Illuminate\Support\Str::limit($t->content, 90)); ?></td>
                    <td><span class="pill <?php echo e($t->is_active ? 'published' : 'off'); ?>"><?php echo e($t->is_active ? 'Aktif' : 'Nonaktif'); ?></span></td>
                    <td class="acts"><a class="btn-line btn-sm-x" href="<?php echo e(route('admin.testimonials.edit', $t)); ?>">Edit</a>
                        <?php echo $__env->make('admin.partials.delete-form', ['action' => route('admin.testimonials.destroy', $t), 'confirm' => 'Hapus testimoni ini?'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/admin/testimonials/index.blade.php ENDPATH**/ ?>