<?php $__env->startSection('title', $page->seo_title ?: $page->title); ?>
<?php $__env->startSection('description', $page->meta_description ?: $page->excerpt); ?>
<?php if($page->image): ?><?php $__env->startSection('image', media_url($page->image)); ?><?php endif; ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.page-header', ['heading' => $page->title, 'crumbs' => [$page->title => null], 'lead' => $page->excerpt], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<section class="pgbody">
    <div class="container">
        <div class="row justify-content-center g-5 align-items-start">
            <?php if($page->image): ?>
                <div class="col-lg-5" data-aos="fade-right">
                    <img src="<?php echo e(media_url($page->image)); ?>" alt="<?php echo e($page->image_alt); ?>" class="pgimg" loading="lazy"/>
                </div>
            <?php endif; ?>
            <div class="<?php echo e($page->image ? 'col-lg-7' : 'col-lg-8'); ?>">
                <div class="prose"><?php echo $page->body; ?></div>
                <?php if($page->slug === 'tentang-kami'): ?>
                    <div class="mt-4 d-flex flex-wrap gap-3">
                        <a href="<?php echo e(route('menu.index')); ?>" class="btn-red"><i class="fas fa-utensils"></i>Lihat Menu</a>
                        <a href="<?php echo e(route('contact')); ?>" class="btn-red btn-ghost"><i class="fas fa-envelope"></i>Hubungi Kami</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/site/page.blade.php ENDPATH**/ ?>