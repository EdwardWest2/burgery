<?php $__env->startSection('title', 'Halaman'); ?>
<?php $__env->startSection('heading', 'Halaman'); ?>

<?php $__env->startSection('content'); ?>
<div class="card-a">
    <p class="hint mb-3">Halaman statis. Informasi kontak, jam buka, dan media sosial diatur di <a href="<?php echo e(route('admin.settings.edit')); ?>">Pengaturan</a>.</p>
    <div class="tbl-wrap"><table class="tbl">
        <thead><tr><th>Judul</th><th>Alamat</th><th>Diperbarui</th><th></th></tr></thead>
        <tbody>
        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="title"><?php echo e($p->title); ?></td>
                <td class="sub">/<?php echo e($p->slug); ?></td>
                <td class="sub"><?php echo e($p->updated_at->translatedFormat('j M Y H:i')); ?></td>
                <td class="acts"><a class="btn-line btn-sm-x" href="<?php echo e(route('admin.pages.edit', $p)); ?>">Edit</a>
                    <a class="btn-line btn-sm-x" href="<?php echo e(url($p->slug)); ?>" target="_blank" rel="noopener">Lihat</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/admin/pages/index.blade.php ENDPATH**/ ?>