<?php $__env->startSection('title', 'Menu'); ?>
<?php $__env->startSection('description', 'Daftar menu '.setting('brand_name').': lihat kategori, foto, deskripsi, harga, dan ketersediaan.'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.page-header', ['heading' => 'Menu Kami', 'crumbs' => ['Menu' => null], 'lead' => 'Pilih kategori atau cari nama menu.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<section id="menu" class="pgbody">
    <div class="container">
        <form method="GET" action="<?php echo e(route('menu.index')); ?>" class="listsearch" role="search">
            <?php if($activeCategory !== ''): ?><input type="hidden" name="kategori" value="<?php echo e($activeCategory); ?>"><?php endif; ?>
            <input type="search" name="q" value="<?php echo e($search); ?>" placeholder="Cari nama menu..." maxlength="100" aria-label="Cari menu">
            <button type="submit" aria-label="Cari"><i class="fas fa-search"></i></button>
        </form>

        <div class="text-center mb-4" data-aos="fade-up">
            <a class="filtbtn <?php echo e($activeCategory === '' ? 'active' : ''); ?>" href="<?php echo e(route('menu.index', array_filter(['q' => $search]))); ?>">Semua</a>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="filtbtn <?php echo e($activeCategory === $c->slug ? 'active' : ''); ?>" href="<?php echo e(route('menu.index', array_filter(['kategori' => $c->slug, 'q' => $search]))); ?>"><?php echo e($c->name); ?> <small>(<?php echo e($c->items_count); ?>)</small></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php if($items->isEmpty()): ?>
            <div class="emptybox">
                <i class="fas fa-magnifying-glass"></i>
                <p>Tidak ada menu yang cocok<?php echo e($search !== '' ? ' dengan "'.$search.'"' : ''); ?>.</p>
                <a href="<?php echo e(route('menu.index')); ?>" class="btn-red">Tampilkan semua menu</a>
            </div>
        <?php else: ?>
            <div class="row g-4" id="mgrid">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials.menu-card', ['item' => $item, 'delay' => $i % 3], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="mt-5 d-flex justify-content-center"><?php echo e($items->links()); ?></div>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\XAMP\htdocs\burgery-restaurant-website\burgery\resources\views/site/menu/index.blade.php ENDPATH**/ ?>